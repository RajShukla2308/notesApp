class Notes{
    constructor(obj){
        this.noteId = obj.noteId
        this.title = obj.title
        this.body = obj.body
    }
}

module.exports = Notes